<?php $__env->startSection('judul', 'TKIT BINA PRESTASI - Jadwal'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-5 bg-light">
        <h3 class="text-center mb-4">Jadwal Sekolah</h3>
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h4 class="font-weight-bold">Kegiatan Harian</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm">
                        <thead class="table-dark text-center">
                            <tr>
                                <th scope="col" style="width: 25%;">Hari</th>
                                <th scope="col">Kegiatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kegiatanHarian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($kegiatan->hari); ?></td>
                                    <td><?php echo e($kegiatan->kegiatan); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h4 class="font-weight-bold">Detail Kegiatan Harian</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm">
                        <thead class="table-dark text-center">
                            <tr>
                                <th scope="col" style="width: 25%;">Pukul</th>
                                <th scope="col">Kegiatan</th>
                                <th scope="col" style="width: 30%;">Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kegiatanHarianDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($detail->pukul); ?></td>
                                    <td><?php echo e($detail->kegiatan); ?></td>
                                    <td class="text-center"><?php echo e($detail->keterangan); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h4 class="font-weight-bold">Ekstrakurikuler</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm">
                        <thead class="table-dark text-center">
                            <tr>
                                <th scope="col" style="width: 25%;">Hari</th>
                                <th scope="col">Kegiatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ekstrakurikuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekstra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($ekstra->hari); ?> Kamis Minggu ke-<?php echo e($ekstra->minggu_ke); ?>

                                    </td>
                                    <td class="text-center"><?php echo e($ekstra->kegiatan); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h4 class="font-weight-bold">Menu Cooking Class</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm">
                        <thead class="table-dark text-center">
                            <tr>
                                <th scope="col" style="width: 25%;">Hari</th>
                                <th scope="col">Tanggal</th>
                                <th scope="col" style="width: 30%;">Menu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $menuCookingClass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php echo e(\Carbon\Carbon::parse($menu->tanggal)->translatedFormat('l')); ?></td>
                                    <td class="text-center">
                                        <?php echo e(\Carbon\Carbon::parse($menu->tanggal)->isoFormat('D MMMM YYYY')); ?></td>
                                    <td class="text-center"><?php echo e($menu->menu); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h4 class="font-weight-bold">Menu Sehat POMG</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm">
                        <thead class="table-dark text-center">
                            <tr>
                                <th scope="col" style="width: 25%;">Bulan</th>
                                <th scope="col">Hari dan Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-center">Agustus</td>
                                <td class="text-center">Jumat, 16 Agustus 2024</td>
                            </tr>
                            <tr>
                                <td class="text-center">September</td>
                                <td class="text-center">Kamis, 12 September 2024</td>
                            </tr>
                            <tr>
                                <td class="text-center">Oktober</td>
                                <td class="text-center">Kamis, 31 Oktober 2024</td>
                            </tr>
                            <tr>
                                <td class="text-center">November</td>
                                <td class="text-center">Kamis, 13 November 2024</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h4 class="font-weight-bold">Kegiatan Semester</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm">
                        <thead class="table-dark text-center">
                            <tr>
                                <th scope="col" style="width: 25%;">Tanggal</th>
                                <th scope="col">Kegiatan</th>
                                <th scope="col" style="width: 30%;">Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kegiatanSemester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php echo e(\Carbon\Carbon::parse($kegiatan->tanggal)->translatedFormat('l')); ?>,
                                        <?php echo e(\Carbon\Carbon::parse($kegiatan->tanggal)->isoFormat('D MMMM YYYY')); ?>

                                    </td>
                                    <td><?php echo e($kegiatan->kegiatan); ?></td>
                                    <td class="text-center"><?php echo e($kegiatan->keterangan); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        .card {
            border-radius: 10px;
        }
        .card-header {
            background-color: #343a40;
            color: white;
        }
        .font-weight-bold {
            font-weight: bold !important;
        }
        .mb-4 {
            margin-bottom: 1.5rem !important;
        }
        .mb-3 {
            margin-bottom: 1rem !important;
        }
        .bg-light {
            background-color: #f8f9fa !important;
        }
        .table-dark {
            background-color: #343a40;
            color: #fff;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.05);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views/main/jadwal.blade.php ENDPATH**/ ?>