
<?php $__env->startSection('Judul', 'TKIT BINA PRESTASI - Forgot Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-center">Forgot Password</h1>
    <form method="POST" action="<?php echo e(route('password.reset')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="new_password">Password Baru:</label>
            <input type="password" name="new_password" required>
        </div>
        <div class="mb-3">
            <label for="new_password_confirmation">Konfirmasi Password Baru:</label>
            <input type="password" name="new_password_confirmation" required>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Send Password Reset Link</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views//siswa/forgot-password.blade.php ENDPATH**/ ?>