<!-- View untuk tampilan balasan -->
<div class="message reply ms-<?php echo e($level * 4); ?> mt-3 p-2 border-start border-3 rounded-start" style="border-color: #007bff;">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <div>
            <i class="fas fa-user-circle fa-lg text-primary"></i>
            <span class="message-author fw-bold">
                <?php echo e($reply->pengguna ? $reply->pengguna->nama_lengkap : 'Unknown'); ?> (<?php echo e($reply->pengguna->role ?? 'Not Available'); ?>)
            </span>
            <span class="message-time text-muted"><?php echo e(\Carbon\Carbon::parse($reply->waktu_kirim)->locale('id')->diffForHumans()); ?></span>
        </div> 
    </div>
    <p class="message-content"><?php echo e($reply->isi_pesan); ?></p>
    <!-- Tambahkan kontrol edit dan hapus untuk balasan -->
    <?php if($reply->pengguna_id == Session::get('pengguna_id')): ?>
        <div class="mt-2 d-flex">
            <a href="#" class="btn btn-sm btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#editReplyModal<?php echo e($reply->id); ?>">Edit</a>
            <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteReplyModal<?php echo e($reply->id); ?>">Hapus</button>
        </div>
    <?php endif; ?>
    <!-- Tombol balasan muncul hanya jika balasan dibuat oleh orang lain -->
    <?php if($reply->pengguna_id != Session::get('pengguna_id')): ?>
        <?php if($reply->pengguna): ?>
            <button class="btn btn-link btn-sm mt-1 mb-1 text-primary btn-reply-toggle" 
                    data-pesan-id="<?php echo e($reply->id); ?>" 
                    data-pengguna-nama="<?php echo e($reply->pengguna->nama_lengkap); ?>">
                Balas
            </button>
        <?php else: ?>
            <button class="btn btn-link btn-sm mt-1 mb-1 text-primary btn-reply-toggle" 
                    data-pesan-id="<?php echo e($reply->id); ?>" 
                    data-pengguna-nama="Unknown">
                Balas
            </button>
        <?php endif; ?>
    <?php endif; ?>
    <!-- Formulir balasan -->
    <form action="<?php echo e(route('forum.pesan.kirim')); ?>" method="POST" class="mb-2 reply-form" data-pesan-id="<?php echo e($reply->id); ?>" style="display: none;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="parent_id" value="<?php echo e($reply->id); ?>">
        <div class="input-group">
        <textarea name="isi_pesan" class="form-control" placeholder="Balas pesan..." rows="2"></textarea>
            <div class="input-group-append">
                <button type="submit" class="btn btn-primary">Kirim</button>
            </div>
        </div>
    </form>
    <!-- Menampilkan balasan pada balasan -->
    <?php $__currentLoopData = $reply->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childReply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('forum.reply', ['reply' => $childReply, 'level' => $level + 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal Edit Balasan -->
    <div class="modal fade" id="editReplyModal<?php echo e($reply->id); ?>" tabindex="-1" aria-labelledby="editReplyModalLabel<?php echo e($reply->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('forum.pesan.reply.update', $reply->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="editReplyModalLabel<?php echo e($reply->id); ?>">Edit Balasan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="isi_reply<?php echo e($reply->id); ?>" class="form-label">Isi Balasan</label>
                            <textarea class="form-control" id="isi_reply<?php echo e($reply->id); ?>" name="isi_pesan" rows="5"><?php echo e($reply->isi_pesan); ?></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Hapus Balasan -->
    <div class="modal fade" id="deleteReplyModal<?php echo e($reply->id); ?>" tabindex="-1" aria-labelledby="deleteReplyModalLabel<?php echo e($reply->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('forum.pesan.hapus', $reply->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteReplyModalLabel<?php echo e($reply->id); ?>">Konfirmasi Hapus Balasan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah Anda yakin ingin menghapus balasan ini?</p>
                        <p class="fw-bold"><?php echo e($reply->isi_pesan); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views/forum/reply.blade.php ENDPATH**/ ?>