
<?php $__env->startSection('Judul', 'TKIT BINA PRESTASI - Forgot Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-5 pb-5 bg-light menu">
    <div class="container text-center">
        <h1 class="display-2 mb-4">RESET PASSWORD</h1>
    </div>
    <div class="container">
        <form method="POST" action="<?php echo e(route('password.reset')); ?>" class="row g-3">
            <?php echo csrf_field(); ?>
            <div class="col-md-6 mx-auto col-10">
                <div class="card shadow-lg p-4">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">Password Baru</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                    <div class="mb-3">
                        <label for="new_password_confirmation" class="form-label">Konfirmasi Password Baru</label>
                        <input type="password" class="form-control" id="new_password_confirmation" name="new_password_confirmation" required>
                    </div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first()); ?>

                        </div>
                    <?php endif; ?>
                    <div class="mb-3 text-center">
                        <p>Sudah Punya Akun? <a href="/login" class="text-decoration-none">Login Disini</a></p>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-lg">Reset Password</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views/siswa/forgot-password.blade.php ENDPATH**/ ?>