<?php $__env->startSection('judul', 'TKIT BINA PRESTASI - Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card w-100">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-user-circle"></i> Informasi Siswa
                    </div>
                    <div class="card-body">
                        <?php if(isset($biodata)): ?>
                            <div class="mb-3">
                                <p><strong>Nama:</strong> <?php echo e($biodata->nama_lengkap); ?></p>
                                <p><strong>Alamat:</strong> <?php echo e($biodata->alamat); ?></p>
                                <p><strong>No HP:</strong> +62<?php echo e($biodata->no_hp); ?></p>
                                <a href="<?php echo e(route('siswa.biodata', Session::has('pengguna_id') ? Session::get('pengguna_id') : '')); ?>"
                                    class="btn btn-primary mt-3">
                                    <i class="fas fa-edit"></i> Edit Biodata
                                </a>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">Biodata siswa belum diisi. Silahkan isi biodata siswa untuk daftar.</p>
                            <a href="<?php echo e(route('siswa.biodata', Session::has('pengguna_id') ? Session::get('pengguna_id') : '')); ?>"
                                class="btn btn-primary mt-3">
                                <i class="fas fa-edit"></i> Isi Biodata
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views/main/dashboard.blade.php ENDPATH**/ ?>