<?php $__env->startSection('judul', 'TKIT BINA PRESTASI - Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-user-circle"></i> Informasi Admin
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <p><strong>Nama:</strong> <?php echo e($admin->nama_lengkap); ?></p>
                            <p><strong>Email:</strong> <?php echo e($admin->email); ?></p>
                            <p><strong>Role:</strong> Admin</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>