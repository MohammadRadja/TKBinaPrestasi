
<?php $__env->startSection('Judul', 'TKIT BINA PRESTASI - Login Admin'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-5 pb-5 bg-light menu">
        <div class="container text-center">
            <h1 class="display-2 mb-4">LOGIN ADMIN</h1>
        </div>
        <div class="container">
            <form method="POST" action="<?php echo e(route('post.login')); ?>" class="row g-1">
                <?php echo csrf_field(); ?>
                <div class="col-md-6 w-100 mx-auto">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                <div class="col-md-6 mx-auto col-10"> 
                    <div class="card shadow-lg p-4">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3 text-center">
                            <p>Belum Punya Akun? <a href="<?php echo e(route('admin.register')); ?>" class="text-decoration-none">Register Disini</a></p>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg">Login</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views/admin/login.blade.php ENDPATH**/ ?>