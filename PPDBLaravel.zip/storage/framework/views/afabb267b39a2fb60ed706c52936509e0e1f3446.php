<?php $__env->startSection('judul', 'TKIT BINA PRESTASI - Data Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <span>Daftar Siswa</span>
                    <div class="d-flex">
                    <div class="d-flex gap-2 me-3">
                        <select id="sortDropdown" class="form-select form-select-sm">
                            <option value="default">Sort by</option>
                            <option value="asc">A-Z</option>
                            <option value="desc">Z-A</option>
                        </select>
                    </div>
                    <a href="<?php echo e(route('admin.tambah_siswa_view')); ?>" class="btn btn-success btn-sm">
                        Tambah Data
                    </a>
                    </div>
                </div>
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php elseif(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col" style="text-align: center; width: 70%;">Nama Lengkap</th>
                                    <th scope="col" style="text-align: center; width: 30%;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="siswaTableBody">
                                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="border-right: 1px solid #dee2e6;"><?php echo e($item->nama_lengkap); ?></td>
                                    <td class="text-end">
                                        <div class="d-flex gap-2 flex-wrap justify-content-center">
                                            <a href="<?php echo e(route('admin.view_biodata', $item->id)); ?>" class="btn btn-primary btn-sm d-flex align-items-center">
                                                <i class="fas fa-eye me-1"></i> Lihat
                                            </a>
                                            <a href="<?php echo e(route('admin.edit_siswa', $item->id)); ?>" class="btn btn-warning btn-sm d-flex align-items-center">
                                                <i class="fas fa-edit me-1"></i> Edit
                                            </a>
                                            <button class="btn btn-danger btn-sm d-flex align-items-center" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                                <i class="fas fa-trash me-1"></i> Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <div class="modal fade" id="deleteModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="deleteModalLabel<?php echo e($item->id); ?>">
                                                    Konfirmasi Hapus
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Apakah Anda yakin ingin menghapus siswa ini?
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <form action="<?php echo e(route('admin.delete_siswa', $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('sortDropdown').addEventListener('change', function() {
        const sortOrder = this.value;
        const tableBody = document.getElementById('siswaTableBody');
        const rows = Array.from(tableBody.getElementsByTagName('tr'));

        rows.sort((a, b) => {
            const nameA = a.getElementsByTagName('td')[0].innerText.toUpperCase();
            const nameB = b.getElementsByTagName('td')[0].innerText.toUpperCase();

            if (sortOrder === 'asc') {
                return nameA < nameB ? -1 : nameA > nameB ? 1 : 0;
            } else if (sortOrder === 'desc') {
                return nameA > nameB ? -1 : nameA < nameB ? 1 : 0;
            }
            return 0;
        });

        tableBody.innerHTML = '';
        rows.forEach(row => tableBody.appendChild(row));
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views/admin/data_siswa.blade.php ENDPATH**/ ?>