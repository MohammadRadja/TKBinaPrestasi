<?php $__env->startSection('judul', 'Biodata Siswa'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="h3 mb-3">Biodata Siswa</h1>
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">Biodata <?php echo e($biodata->nama_lengkap); ?></div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <th>Nama Lengkap</th>
                                    <td><?php echo e($biodata->nama_lengkap); ?></td>
                                </tr>
                                <tr>
                                    <th>Nama Panggilan</th>
                                    <td><?php echo e($biodata->nama_panggilan); ?></td>
                                </tr>
                                <tr>
                                    <th>Jenis Kelamin</th>
                                    <td><?php echo e($biodata->jenis_kelamin); ?></td>
                                </tr>
                                <tr>
                                    <th>Tempat, Tanggal Lahir</th>
                                    <td><?php echo e($biodata->tempat_tanggal_lahir); ?></td>
                                </tr>
                                <tr>
                                    <th>Agama</th>
                                    <td><?php echo e($biodata->agama); ?></td>
                                </tr>
                                <tr>
                                    <th>Anak Ke</th>
                                    <td><?php echo e($biodata->anak_ke); ?></td>
                                </tr>
                                <tr>
                                    <th>Nama Ayah</th>
                                    <td><?php echo e($biodata->nama_ayah); ?></td>
                                </tr>
                                <tr>
                                    <th>Nama Ibu</th>
                                    <td><?php echo e($biodata->nama_ibu); ?></td>
                                </tr>
                                <tr>
                                    <th>Pekerjaan Ayah</th>
                                    <td><?php echo e($biodata->pekerjaan_ayah); ?></td>
                                </tr>
                                <tr>
                                    <th>Pekerjaan Ibu</th>
                                    <td><?php echo e($biodata->pekerjaan_ibu); ?></td>
                                </tr>
                                <tr>
                                    <th>No HP</th>
                                    <td><?php echo e($biodata->no_hp); ?></td>
                                </tr>
                                <tr>
                                    <th>Alamat</th>
                                    <td><?php echo e($biodata->alamat); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <a href="<?php echo e(route('admin.data_siswa')); ?>" class="btn btn-secondary mt-3">Kembali</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PPDBLaravel\resources\views/admin/view_biodata.blade.php ENDPATH**/ ?>