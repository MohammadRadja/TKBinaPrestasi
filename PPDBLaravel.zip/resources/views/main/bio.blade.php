@extends('ppdbtk.template')
@section('judul', 'TKIT BINA PRESTASI - Biodata Siswa')
@section('content')
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h3 class="text-center font-weight-500">BIODATA SISWA</h3>
                <p class="lead text-center">Silahkan isi form berikut untuk mendaftar di TKIT Bina Prestasi</p>
            </div>
            <div class="card-body">
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @elseif (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                <form method="POST" action="{{ route('siswa.biodata.save') }}">
                    @csrf
                    <div class="mb-3">
                        <label for="fullName" class="form-label">Nama Lengkap</label>
                        <input type="text" name="fullName" class="form-control @error('fullName') is-invalid @enderror"
                            id="fullName" value="{{ old('fullName', $biodata ? $biodata->nama_lengkap : '') }}" required />
                        @error('fullName')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="nickName" class="form-label">Nama Panggilan</label>
                        <input type="text" name="nickName" class="form-control @error('nickName') is-invalid @enderror"
                            id="nickName" value="{{ old('nickName', $biodata ? $biodata->nama_panggilan : '') }}"
                            required />
                        @error('nickName')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="gender" class="form-label">Jenis Kelamin</label>
                        <select name="gender" class="form-select @error('gender') is-invalid @enderror" id="gender"
                            required>
                            <option value="" disabled>Pilih</option>
                            <option value="Laki-laki"
                                {{ old('gender', $biodata ? $biodata->jenis_kelamin : '') == 'Laki-laki' ? 'selected' : '' }}>
                                Laki-laki</option>
                            <option value="Perempuan"
                                {{ old('gender', $biodata ? $biodata->jenis_kelamin : '') == 'Perempuan' ? 'selected' : '' }}>
                                Perempuan</option>
                        </select>
                        @error('gender')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="birthPlaceDate" class="form-label">Tempat, Tanggal Lahir</label>
                        <input type="text" name="birthPlaceDate"
                            class="form-control @error('birthPlaceDate') is-invalid @enderror" id="birthPlaceDate"
                            value="{{ old('birthPlaceDate', $biodata ? $biodata->tempat_tanggal_lahir : '') }}"
                            placeholder="Contoh: Jakarta, 1 Januari 2024" required />
                        @error('birthPlaceDate')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="agama" class="form-label">Agama</label>
                        <select name="agama" class="form-select @error('agama') is-invalid @enderror" id="agama"
                            required>
                            <option value="" disabled>Pilih</option>
                            <option value="Islam"
                                {{ old('agama', $biodata ? $biodata->agama : '') == 'Islam' ? 'selected' : '' }}>Islam
                            </option>
                            <option value="Kristen Protestan"
                                {{ old('agama', $biodata ? $biodata->agama : '') == 'Kristen Protestan' ? 'selected' : '' }}>
                                Kristen Protestan</option>
                            <option value="Kristen Katolik"
                                {{ old('agama', $biodata ? $biodata->agama : '') == 'Kristen Katolik' ? 'selected' : '' }}>
                                Kristen Katolik</option>
                            <option value="Hindu"
                                {{ old('agama', $biodata ? $biodata->agama : '') == 'Hindu' ? 'selected' : '' }}>Hindu
                            </option>
                            <option value="Buddha"
                                {{ old('agama', $biodata ? $biodata->agama : '') == 'Buddha' ? 'selected' : '' }}>Buddha
                            </option>
                            <option value="Konghucu"
                                {{ old('agama', $biodata ? $biodata->agama : '') == 'Konghucu' ? 'selected' : '' }}>
                                Konghucu</option>
                        </select>
                        @error('agama')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="anakKe" class="form-label">Anak ke-</label>
                        <input type="text" name="anakKe" class="form-control @error('anakKe') is-invalid @enderror"
                            id="anakKe" value="{{ old('anakKe', $biodata ? $biodata->anak_ke : '') }}" required />
                        @error('anakKe')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="parentNameAyah" class="form-label">Nama Ayah</label>
                        <input type="text" name="parentNameAyah"
                            class="form-control @error('parentNameAyah') is-invalid @enderror" id="parentNameAyah"
                            value="{{ old('parentNameAyah', $biodata ? $biodata->nama_ayah : '') }}" required />
                        @error('parentNameAyah')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="parentNameIbu" class="form-label">Nama Ibu</label>
                        <input type="text" name="parentNameIbu"
                            class="form-control @error('parentNameIbu') is-invalid @enderror" id="parentNameIbu"
                            value="{{ old('parentNameIbu', $biodata ? $biodata->nama_ibu : '') }}" required />
                        @error('parentNameIbu')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="profesiayah" class="form-label">Profesi Ayah</label>
                        <input type="text" name="profesiayah"
                            class="form-control @error('profesiayah') is-invalid @enderror" id="profesiayah"
                            value="{{ old('profesiayah', $biodata ? $biodata->pekerjaan_ayah : '') }}" required />
                        @error('profesiayah')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="profesiibu" class="form-label">Profesi Ibu</label>
                        <input type="text" name="profesiibu"
                            class="form-control @error('profesiibu') is-invalid @enderror" id="profesiibu"
                            value="{{ old('profesiibu', $biodata ? $biodata->pekerjaan_ibu : '') }}" required />
                        @error('profesiibu')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="telayah" class="form-label">No. HP/WhatsApp Ayah</label>
                        <input type="text" name="telayah" class="form-control @error('telayah') is-invalid @enderror"
                            id="telayah" value="{{ old('telayah', $biodata ? $biodata->no_hp : '') }}"
                            placeholder="62123456789" required />
                        @error('telayah')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Alamat</label>
                        <textarea name="address" class="form-control @error('address') is-invalid @enderror" id="address" rows="3"
                            required>{{ old('address', $biodata ? $biodata->alamat : '') }}</textarea>
                        @error('address')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
@endsection