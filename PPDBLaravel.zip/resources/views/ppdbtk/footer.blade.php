<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    &copy;<strong> Copyright 2024</strong>
                </p>
            </div>
        </div>
    </div>
</footer>