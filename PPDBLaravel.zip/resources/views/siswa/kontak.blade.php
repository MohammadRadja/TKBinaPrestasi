@extends('master.template')
@section('Judul', 'TKIT BINA PRESTASI - Kontak')
@section('content')
    <!-- Contact Information -->
    <div class="container py-5 menu">
        <div class="row">
            <div class="col-md-6">
                <h1 class="mb-4">KONTAK KAMI</h1>
                <ul class="list-unstyled-kontak">
                    <p><i class="fas fa-envelope me-2"></i>Email: <a
                            href="mailto:tkitbinaprestasi@gmail.com">tkitbinaprestasi@gmail.com</a></p>
                    <p><i class="fab fa-whatsapp me-2"></i>WhatsApp: </><a href="http://wa.me/6285765549259">+62
                            857-6554-9259</a></p>
                    <p><i class="fab fa-facebook-f me-3"></i>Facebook: <a
                            href="https://www.facebook.com/share/nm7a3SsewkULnfoX/?mibextid=qi2Omg">Bina Prestasi</a></p>
                    <p><i class="fab fa-instagram me-2"></i>Instagram: <a
                            href="https://www.instagram.com/kelasbinaprestasi?igsh=b3M3NXN4MHRha3l4">kelasbinaprestasi</a>
                    </p>
                    <p><i class="fab fa-youtube me-2"></i>Youtube: <a
                            href="https://youtube.com/@tutymunawaroh7767?si=rkrmZ1Du5fIcoeOj">Tuty Munawaroh</a></p>
                    <p><i class="fas fa-map-marker-alt me-2"></i>Alamat: <a
                            href="https://maps.app.goo.gl/n2S7fMC76V5HtWrY6">Villa Mutiara Pluit Blok F3 No. 43, RT 007, RW
                            009, Kel. Periuk, Kec. Periuk, Kota Tangerang, Banten 15131</a></p>
                </ul>
            </div>
            <div class="col-md-6 mt-5">
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126916.86337892224!2d106.45518198216801!3d-6.243692790247523!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ff4420ebe04f%3A0x61aa392b92b6c047!2sTK%20BINA%20PRESTASI%20(ISLAM%20TERPADU)!5e0!3m2!1sid!2sid!4v1720557584165!5m2!1sid!2sid"
                        style="border:0; width:100%; height:270px" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>
    <!-- End Contact Information -->
    <!-- Back to Top Button -->
    <div class="back-to-top" id="backToTopBtn" title="Go to top">
        <i class="fas fa-arrow-up"></i>
    </div>
    <!-- End Back to Top Button -->
@endsection