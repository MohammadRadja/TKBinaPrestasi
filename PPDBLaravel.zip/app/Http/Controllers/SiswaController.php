<?php

namespace App\Http\Controllers;

use App\Models\Pengguna;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\BiodataDiri;
use Illuminate\Support\Facades\Hash;
use App\Models\Siswa;
use App\Models\Ekstrakurikuler;
use App\Models\JadwalMasukSekolah;
use App\Models\KegiatanHarian;
use App\Models\KegiatanHarianDetail;
use App\Models\KegiatanSemester;
use App\Models\MenuCookingClass;
use App\Models\MenuSehatPOMG;

class SiswaController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (!Session::has('pengguna_id')) {
                return redirect('/login');
            }

            return $next($request);
        });
    }

    public function dashboard()
    {
        if (!session('pengguna_id')) {
            return redirect()->route('login')->withErrors(['message' => 'Anda harus login terlebih dahulu.']);
        }

        $pengguna_id = session('pengguna_id');
        $biodata = BiodataDiri::where('pengguna_id', $pengguna_id)->first();
        return view('main.dashboard', [
            'biodata' => $biodata
        ]);
    }

    public function biodata()
    {
        if (!session('pengguna_id')) {
            return redirect()->route('login')->withErrors(['message' => 'Anda harus login terlebih dahulu.']);
        }

        $pengguna_id = session('pengguna_id');
        $biodata = BiodataDiri::where('pengguna_id', $pengguna_id)->first();

        return view('main.bio', [
            'biodata' => $biodata,
        ]);
    }

    public function biodatasave(Request $request)
    {
        $request->validate([
            'fullName' => 'required|string|max:255',
            'nickName' => 'required|string|max:255',
            'gender' => 'required|string|in:Laki-laki,Perempuan',
            'birthPlaceDate' => 'required|string|max:255',
            'agama' => 'required|string|in:Islam,Kristen Protestan,Kristen Katolik,Hindu,Buddha,Konghucu',
            'anakKe' => 'required|integer|min:1|max:99',
            'parentNameAyah' => 'required|string|max:255',
            'parentNameIbu' => 'required|string|max:255',
            'profesiayah' => 'required|string|max:255',
            'profesiibu' => 'required|string|max:255',
            'telayah' => 'required|numeric|digits_between:10,15',
            'address' => 'required|string|max:500',
        ], [
            'gender.in' => 'Jenis Kelamin harus Laki-laki atau Perempuan.',
            'agama.in' => 'Agama harus salah satu dari Islam, Kristen Protestan, Kristen Katolik, Hindu, Buddha, atau Konghucu.',
            'anakKe.integer' => 'Anak ke- harus berupa angka.',
            'telayah.numeric' => 'No. HP/WhatsApp harus berupa angka.',
            'telayah.digits_between' => 'No. HP/WhatsApp harus terdiri dari 10 hingga 15 digit.',
        ]);

        try {
            $pengguna_id = session('pengguna_id');
            // Periksa apakah biodata sudah ada
            $biodata = BiodataDiri::where('pengguna_id', $pengguna_id)->first();

            if ($biodata) {
                // Jika biodata sudah ada, update data yang ada
                $biodata->update([
                    'nama_lengkap' => $request->input('fullName'),
                    'nama_panggilan' => $request->input('nickName'),
                    'jenis_kelamin' => $request->input('gender'),
                    'tempat_tanggal_lahir' => $request->input('birthPlaceDate'),
                    'agama' => $request->input('agama'),
                    'anak_ke' => $request->input('anakKe'),
                    'nama_ayah' => $request->input('parentNameAyah'),
                    'nama_ibu' => $request->input('parentNameIbu'),
                    'pekerjaan_ayah' => $request->input('profesiayah'),
                    'pekerjaan_ibu' => $request->input('profesiibu'),
                    'no_hp' => $request->input('telayah'),
                    'alamat' => $request->input('address')
                ]);

                $message = 'Biodata berhasil diperbarui';
            } else {
                // Jika biodata belum ada, buat data baru
                BiodataDiri::create([
                    'pengguna_id' => $pengguna_id,
                    'nama_lengkap' => $request->input('fullName'),
                    'nama_panggilan' => $request->input('nickName'),
                    'jenis_kelamin' => $request->input('gender'),
                    'tempat_tanggal_lahir' => $request->input('birthPlaceDate'),
                    'agama' => $request->input('agama'),
                    'anak_ke' => $request->input('anakKe'),
                    'nama_ayah' => $request->input('parentNameAyah'),
                    'nama_ibu' => $request->input('parentNameIbu'),
                    'pekerjaan_ayah' => $request->input('profesiayah'),
                    'pekerjaan_ibu' => $request->input('profesiibu'),
                    'no_hp' => $request->input('telayah'),
                    'alamat' => $request->input('address')
                ]);

                $message = 'Biodata berhasil disimpan. Silahkan tunggu konfirmasi lebih lanjut dari Admin di WhatsApp.';
            }

            return redirect()->back()->with('success', $message);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal menyimpan biodata: ' . $e->getMessage());
        }
    }

    public function logout(Request $request)
    {
        Session::flush();
        return redirect('/login')->with('success', 'Anda telah logout.');
    }

    public function profil()
    {
        // Ambil informasi pengguna yang sedang login
        $pengguna = Pengguna::findOrFail(Session::get('pengguna_id'));

        // Kirim data pengguna ke view profil
        return view('main.profil', compact('pengguna'));
    }

    public function updateProfil(Request $request)
    {
        $request->validate([
            'nama_lengkap' => 'required|string|max:100',
            'email' => 'required|string|email|max:100',
            'password' => 'nullable|string|min:6|confirmed', // tambahkan validasi password
        ]);

        try {
            // Ambil pengguna yang sedang login
            $pengguna = Pengguna::findOrFail(Session::get('pengguna_id'));

            // Perbarui informasi profil
            $pengguna->nama_lengkap = $request->input('nama_lengkap');
            $pengguna->email = $request->input('email');

            // Perbarui password jika dimasukkan
            if ($request->filled('password')) {
                $pengguna->password = Hash::make($request->input('password'));

                // Simpan perubahan profil
                $pengguna->save();

                // Hapus semua s    ession
                Session::flush();

                // Redirect ke halaman login dengan pesan sukses
                return redirect('/login')->with('success', 'Password berhasil diubah. Silakan login kembali.');
            }

            // Simpan perubahan profil tanpa menghapus session
            $pengguna->save();

            return redirect()->route('siswa.profil')->with('success', 'Profil berhasil diperbarui.');
        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Gagal memperbarui profil. Silakan coba lagi.']);
        }
    }

    public function showJadwal()
    {
        // Ambil data dari masing-masing tabel menggunakan model

        $kegiatanHarian = KegiatanHarian::all();
        $kegiatanHarianDetail = KegiatanHarianDetail::all();
        $ekstrakurikuler = Ekstrakurikuler::all();
        $menuCookingClass = MenuCookingClass::all();
        $menuSehatPOMG = MenuSehatPOMG::all();
        $kegiatanSemester = KegiatanSemester::all();

        // Tampilkan view 'jadwal' dengan data yang telah diambil

        return view('main.jadwal', compact('kegiatanHarian', 'kegiatanHarianDetail', 'ekstrakurikuler', 'menuCookingClass', 'menuSehatPOMG', 'kegiatanSemester'));
    }
}