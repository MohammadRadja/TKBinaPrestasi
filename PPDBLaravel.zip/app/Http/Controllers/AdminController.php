<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pengguna;
use App\Models\Siswa;
use App\Models\BiodataDiri;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log; // Tambahkan ini

class AdminController extends Controller
{

    public function __construct()
    {
        // Middleware untuk memeriksa peran admin
        $this->middleware(function ($request, $next) {
            if ($request->is('admin/*') && $request->session()->has('pengguna_id')) {
                $pengguna = Pengguna::findOrFail($request->session()->get('pengguna_id'));
                if ($pengguna->role !== 'admin') {
                    return redirect()->route('login')->with('error', 'Anda bukan admin. Akses ditolak.');
                }
            } elseif ($request->is('admin/*')) {
                return redirect()->route('login')->with('error', 'Silakan login terlebih dahulu.');
            }

            return $next($request);
        });
    }

    public function dashboard()
    {
        $adminId = session('pengguna_id');
        $admin = Pengguna::findOrFail($adminId);

        return view('admin.dashboard', compact('admin'));
    }

    // Method untuk halaman data siswa
    public function dataSiswa()
    {
        // Ambil semua pengguna dengan role 'siswa'
        $siswa = Pengguna::where('role', 'siswa')->get();
        return view('admin.data_siswa', ['siswa' => $siswa]);
    }

    // Method untuk menampilkan biodata siswa
    public function viewBiodata($id)
    {
        // Ambil biodata berdasarkan pengguna ID
        $biodata = BiodataDiri::where('pengguna_id', $id)->firstOrFail();
        return view('admin.view_biodata', ['biodata' => $biodata]);
    }

    // AdminController.php
    public function tambahSiswaView()
    {
        return view('admin.tambah_siswa');
    }

    public function tambahSiswa(Request $request)
    {
        // Validasi input dari form
        $validatedData = $request->validate([
            'nama_lengkap' => 'required|string|max:255',
            'nama_panggilan' => 'required|string|max:255',
            'jenis_kelamin' => 'required|string|in:Laki-laki,Perempuan',
            'tempat_tanggal_lahir' => 'required|string|max:255',
            'agama' => 'required|string|max:255',
            'anak_ke' => 'required|string|max:255',
            'nama_ayah' => 'required|string|max:255',
            'nama_ibu' => 'required|string|max:255',
            'pekerjaan_ayah' => 'required|string|max:255',
            'pekerjaan_ibu' => 'required|string|max:255',
            'no_hp' => 'required|string|max:255',
            'alamat' => 'required|string|max:255',
            'username' => 'required|string|unique:pengguna|max:255',
            'email' => 'required|email|unique:pengguna|max:255',
            'password' => 'required|string|min:6|max:255',
        ]);

        try {
            // Buat pengguna baru
            $pengguna = Pengguna::create([
                'nama_lengkap' => $validatedData['nama_lengkap'],
                'username' => $validatedData['username'],
                'email' => $validatedData['email'],
                'password' => bcrypt($validatedData['password']), // Jangan lupa untuk meng-hash password
                'role' => 'siswa', // Atur role pengguna jika perlu
            ]);

            // Ambil ID pengguna yang baru dibuat
            $penggunaId = $pengguna->id;

            // Buat biodata diri berdasarkan pengguna_id
            BiodataDiri::create([
                'pengguna_id' => $penggunaId,
                'nama_lengkap' => $validatedData['nama_lengkap'],
                'nama_panggilan' => $validatedData['nama_panggilan'],
                'jenis_kelamin' => $validatedData['jenis_kelamin'],
                'tempat_tanggal_lahir' => $validatedData['tempat_tanggal_lahir'],
                'agama' => $validatedData['agama'],
                'anak_ke' => $validatedData['anak_ke'],
                'nama_ayah' => $validatedData['nama_ayah'],
                'nama_ibu' => $validatedData['nama_ibu'],
                'pekerjaan_ayah' => $validatedData['pekerjaan_ayah'],
                'pekerjaan_ibu' => $validatedData['pekerjaan_ibu'],
                'no_hp' => $validatedData['no_hp'],
                'alamat' => $validatedData['alamat'],
            ]);

            // Redirect dengan pesan sukses
            return redirect()->route('admin.data_siswa')->with('success', 'Data siswa berhasil ditambahkan.');
        } catch (\Exception $e) {
            // Tangani jika terjadi error
            return redirect()->back()->withInput()->with('error', 'Gagal menambahkan data siswa. Silakan coba lagi.');
        }
    }

    public function editSiswa($id)
    {
        $siswa = Pengguna::findOrFail($id); // Ensure you are getting a single model instance
        $biodata = BiodataDiri::where('pengguna_id', $id)->firstOrFail();
        return view('admin.edit_siswa', compact('siswa', 'biodata'));
    }

    public function updateSiswa(Request $request, $id)
    {
        $request->validate([
            'nama_lengkap' => 'required|string|max:100',
            'nama_panggilan' => 'required|string|max:100',
            'jenis_kelamin' => 'required|in:Laki-laki,Perempuan',
            'tempat_tanggal_lahir' => 'required|string',
            'agama' => 'required|string',
            'anak_ke' => 'required|integer',
            'nama_ayah' => 'required|string|max:100',
            'nama_ibu' => 'required|string|max:100',
            'pekerjaan_ayah' => 'required|string',
            'pekerjaan_ibu' => 'required|string',
            'no_hp' => 'required|numeric|digits_between:10,15',
            'alamat' => 'required|string',
        ], [
            'jenis_kelamin.in' => 'Jenis Kelamin harus Laki-laki atau Perempuan.',
            'agama.in' => 'Agama harus salah satu dari Islam, Kristen Protestan, Kristen Katolik, Hindu, Buddha, atau Konghucu.',
            'anak_ke.integer' => 'Anak ke- harus berupa angka.',
            'no_hp.numeric' => 'No. HP/WhatsApp harus berupa angka.',
            'no_hp.digits_between' => 'No. HP/WhatsApp harus terdiri dari 10 hingga 15 digit.',
        ]);

        $siswa = Pengguna::findOrFail($id);
        $siswa->update([
            'nama_lengkap' => $request->nama_lengkap,
        ]);

        $biodata = BiodataDiri::where('pengguna_id', $id)->firstOrFail();
        $biodata->update([
            'nama_lengkap' => $request->nama_lengkap,
            'nama_panggilan' => $request->nama_panggilan,
            'jenis_kelamin' => $request->jenis_kelamin,
            'tempat_tanggal_lahir' => $request->tempat_tanggal_lahir,
            'agama' => $request->agama,
            'anak_ke' => $request->anak_ke,
            'nama_ayah' => $request->nama_ayah,
            'nama_ibu' => $request->nama_ibu,
            'pekerjaan_ayah' => $request->pekerjaan_ayah,
            'pekerjaan_ibu' => $request->pekerjaan_ibu,
            'no_hp' => $request->no_hp,
            'alamat' => $request->alamat,
        ]);

        return redirect()->route('admin.data_siswa')->with('success', 'Data siswa berhasil diedit');
    }


    public function deleteSiswa($id)
    {
        $siswa = Pengguna::findOrFail($id);
        $siswa->delete();

        return redirect()->route('admin.data_siswa')->with('success', 'Data siswa berhasil dihapus.');
    }
}